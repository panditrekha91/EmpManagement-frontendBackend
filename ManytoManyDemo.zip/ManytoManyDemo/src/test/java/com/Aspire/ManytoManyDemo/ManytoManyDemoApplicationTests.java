package com.Aspire.ManytoManyDemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ManytoManyDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
